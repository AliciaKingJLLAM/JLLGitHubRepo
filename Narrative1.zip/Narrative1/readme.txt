>>Close Word AND Excel before proceeding.<<

===============================================

This installer will create the necessary files for Report Writer on your computer.

Once the installer is run, it will prompt you to open and run the Updater.  

The Updater will request your credentials before obtaining the remaining 
files necessary to run the Report Writing components.

Once the Updater has run, please enable macros within Word and Excel.  
This setting is found in the File menu > Options > Trust Center.  
Click on the Trust Center Settings button and select Macro settings on the left.  
Select the fourth option, "Enable all macros."

If you need any assistance, our support team may be reached at 
support@narrative1.com.

===============================================
